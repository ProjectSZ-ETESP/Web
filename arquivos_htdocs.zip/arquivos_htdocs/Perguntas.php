<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagens/logoLight.webp" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/fqa.css">

    <title>FQA</title>
</head>
<body>

    <div class="principal">
        
        <header>
            <div class="divlogo">
                <a href="Index.php">  
                    <img src="Imagens/logoLight.webp" alt="logo" class="logo" id="logotipo">
                </a>
            </div>
            
            <div class="menu">
                <a href="Clinicas.html" class="fonte">Clínicas</a> <br>
                <a href="Consultas.php" class="fonte">Consultas</a> <br>
                <a href="Conta.php" class="fonte">Conta</a> <br>
                <a href="Index.php" class="fonte">Início</a> <br>
            </div>

            <div class="switch">
                <div id="btnSwitch">
                        <div class="eclipse"> 
                        </div>
                        <img src="Imagens/light.webp" alt="sol" id="imgLight">
                        <img src="Imagens/dark.webp" alt="lua" id="imgDark">
                </div>
            </div>

        </header>

        <h2 class="fontes"> Perguntas Frequentes</h2>

        <div class="perguntas">

            <div class="pergunta">

                <div class="left">
                    <img src="Imagens/perguntasLight.webp" id="question1" class="ask" alt="ponto de interrogação em foramato de localização">

                    <h3 class="fontes">
                        Título da pergunta, a escala richter é uma medida utilizada...
                    </h3>
                </div>

                <p class="fontes">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco 
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit
                </p>

                <div class="left">
                    <img src="Imagens/perguntasLight.webp" id="question2" class="ask" alt="ponto de interrogação em formato de localização">

                    <h3 class="fontes">
                        A escala richter é uma medida utilizada?
                    </h3>
                </div>

                <p class="fontes">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco 
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit
                </p>
            </div>

            <div class="pergunta">

                <div class="left">
                    <img src="Imagens/perguntasLight.webp" id="question3" class="ask" alt="ponto de interrogação em formato de localização">

                    <h3 class="fontes">
                        A escala richter é uma medida utilizada?
                    </h3>
                </div>

                <p class="fontes">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco 
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit
                </p>

                <div class="left">
                    <img src="Imagens/perguntasLight.webp" id="question4" class="ask" alt="pontos de interrogação em formato de localização">

                    <h3 class="fontes">
                    Título da pergunta, a escala richter é uma medida utilizada...
                    </h3>
                </div>

                <p class="fontes">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco 
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit
                </p>
            </div>
            
        </div>
        
        <footer class="botao">
                <div class="sobre">
                    <h3>Sobre nós</h3>
                    <a href="Criacionistas.php">Criacionistas</a> <br>
                    <a href="Perguntas.php">FAQ</a> <br>
                </div>

                <div class="siga">
                    <h3>Siga-nos</h3>
                    <a href="instagram.com">
                        <img src="Imagens/instagram.webp" class="redes" alt="Logo do Instagram">
                    </a>
                    <a href="www.github.com">
                        <img src="Imagens/github.webp" class="redes" alt="Logo do Github">
                    </a>
                </div>
        </footer>
    </div>
    <script src="JS/switch.js"></script>
</body>
</html>
