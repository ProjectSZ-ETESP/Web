<?php
    session_start();

    if (!(isset($_SESSION["idLog"]))) {
        $_SESSION["idLog"] = "";
        $_SESSION["nomeLog"] = "";
        $_SESSION["emailLog"] = "";
        $_SESSION["dataLog"] = "";
        $_SESSION["sexoLog"] = "";
        $_SESSION["telLog"] = "";
        $_SESSION["cpfLog"] = "";
    }
    if (!(isset($_SESSION["idConsul"]))) {
        $_SESSION["idConsul"] = "";
    }

    if ($_SESSION["idLog"] == "") {
        header("Location: ./Login.php");
    }


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/consultas.css">
    <link rel="shortcut icon" href="Imagens/logoLight.webp" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico</title>

</head>
<body>
    <header>
        <div class="divlogo">
            <a href="Index.php">
                <img src="Imagens/logoLight.webp" alt="logo" class="logo" id="logotipo">
            </a>
        </div>
        <div class="menu">
            <a href="Cadastro.php" class="fonte">Cadastro</a> <br>
            <a href="Index.php" class="fonte">Início</a> <br>
            <a href="Conta.php" class="fonte">Conta</a> <br>
            <a href="Perguntas.php" class="fonte">FAQ</a> <br>
        </div>
        <div class="switch">
            <div id="btnSwitch">
                <div class="eclipse"></div>
                <img src="Imagens/light.webp" alt="sol" id="imgLight">
                <img src="Imagens/dark.webp" alt="lua" id="imgDark">
            </div>
        </div>
    </header>
    <div class="principal">
        
        <h2 class="fontes" id="histUser">
            Histórico de Consultas: Bombom
        </h2>

        <div class="ficha">
            <p class="data fontes">
                Efetuado às 10:00 <span>10/05/2024</span>
            </p>

            <p class="dados fontes"> 
                <span>Clínica: </span> Clínica Prof. Dr. Cláudio Gerônimo <br>

                <span>Doutor: </span> Peter Capaldi <br>

                <span>Atendimento: </span> Exame de sangue <br>
            </p>

            <p class="fontes">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin elementum velit, a dapibus mauris maximus quis. Etiam tortor ante, rutrum nec hendrerit quis, ultricies at nunc. Integer sagittis ornare congue. Duis volutpat egestas mauris, ac scelerisque ligula molestie at. Vivamus eu luctus odio. Suspendisse at rhoncus ante, nec tincidunt ante. Integer vulputate bibendum nibh, vitae dictum tortor molestie eu.
            </p>
        </div>


    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            colorMode();
        });

        const idLog = <?php echo json_encode($_SESSION["idLog"]); ?>;
        const nomeLog = <?php echo json_encode($_SESSION["nomeLog"]); ?>;
        const principal = document.querySelector(".principal");
        document.getElementById("histUser").innerHTML = "Histórico de Consultas: " + nomeLog;

            const countConsul = <?php echo json_encode($_SESSION["countConsul"]); ?>;
            const dataConsul = <?php echo json_encode($_SESSION["dataConsul"]); ?>;
            const horaConsul = <?php echo json_encode($_SESSION["horaConsul"]); ?>;
            const clinicaConsul = <?php echo json_encode($_SESSION["clinicaConsul"]); ?>;

        for (let i = 0; i <= countConsul; i++) {
            let ficha = document.createElement('div');
            ficha.classList.add("ficha");
            principal.appendChild(ficha);

            let data = document.createElement('p');
            data.classList.add("data");
            data.classList.add("fontes");
            ficha.appendChild(data);
            data.innerHTML = "Efetuado às " + horaConsul[i] + " " + dataConsul[i];

            let dados = document.createElement('p');
            dados.classList.add("dados");
            dados.classList.add("fontes");
            ficha.appendChild(dados);

            let s1 = document.createElement('span');
            dados.appendChild(s1);
            s1.innerHTML = "Clínica: " + clinicaConsul;

            let s2 = document.createElement('span');
            dados.appendChild(s2);
            s2.innerHTML = "b";

            let s3 = document.createElement('span');
            dados.appendChild(s3);
            s3.innerHTML = "c";

            let descricao = document.createElement('p');
            descricao.classList.add("fontes");
            ficha.appendChild(descricao);
            descricao.innerHTML = "AHAHAHAHAHAHAH";
        }
    </script>
    <script src="JS/switch.js"></script>

</body>
</html>
