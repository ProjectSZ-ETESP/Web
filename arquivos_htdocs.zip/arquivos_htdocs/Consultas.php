<?php
    session_start();

    if (!(isset($_SESSION["idLog"]))) {
        $_SESSION["idLog"] = "";
        $_SESSION["nomeLog"] = "";
        $_SESSION["emailLog"] = "";
        $_SESSION["dataLog"] = "";
        $_SESSION["sexoLog"] = "";
        $_SESSION["telLog"] = "";
        $_SESSION["cpfLog"] = "";
    }
    if (!(isset($_SESSION["idConsul"]))) {
        $_SESSION["idConsul"] = "";
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/consultas.css">
    <link rel="shortcut icon" href="Imagens/iconpfp.webp" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico</title>

</head>
<body>
    <div class="principal">
        <header>
            <div class="divlogo">
                <a href="Index.php">
                    <img src="Imagens/logoLight.webp" alt="logo" class="logo" id="logotipo">
                </a>
            </div>
            <div class="menu">
                <a href="Clinicas.php" class="fonte">Clínicas</a> <br>
                <a href="Index.php" class="fonte">Início</a> <br>
                <a href="Conta.php" class="fonte">Conta</a> <br>
                <a href="Perguntas.php" class="fonte">FAQ</a> <br>
            </div>
            <div class="switch">
                <div id="btnSwitch">
                    <div class="eclipse"></div>
                    <img src="Imagens/light.webp" alt="sol" id="imgLight">
                    <img src="Imagens/dark.webp" alt="lua" id="imgDark">
                </div>
            </div>
        </header>

        <h2 class="fontes" id="histUser">
            Histórico de Consultas: Bombom
        </h2>

        <div class="ficha">
            <p class="data fontes">
                Efetuado às 10:00 <span>10/05/2024</span>
            </p>

            <p class="dados fontes"> 
                <span>Clínica: </span> Clínica Prof. Dr. Cláudio Gerônimo <br>

                <span>Doutor: </span> Peter Capaldi <br>

                <span>Atendimento: </span> Exame de sangue <br>
            </p>

            <p class="fontes">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin elementum velit, a dapibus mauris maximus quis. Etiam tortor ante, rutrum nec hendrerit quis, ultricies at nunc. Integer sagittis ornare congue. Duis volutpat egestas mauris, ac scelerisque ligula molestie at. Vivamus eu luctus odio. Suspendisse at rhoncus ante, nec tincidunt ante. Integer vulputate bibendum nibh, vitae dictum tortor molestie eu.
            </p>
        </div>


    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            dataCheck();
            colorMode();
        });

        function dataCheck() {
            const idLog = <?php echo json_encode($_SESSION["idLog"]); ?>;

            if (idLog == 0 || idLog == "" || idLog == null) {
                window.location.href = "Login.php";
            }
            else {
                consultar();
            }
        }

        function consultar() {
            const idLog = <?php echo json_encode($_SESSION["idLog"]); ?>;
            const idConsul = <?php echo json_encode($_SESSION["idConsul"]); ?>;
            const nomeLog = <?php echo json_encode($_SESSION["nomeLog"]); ?>;

            document.getElementById("histUser").innerHTML = "Histórico de Consultas: " + nomeLog;

            if (idLog != idConsul) {
                window.location = "includes/consultaLoad.inc.php";

            }
            //else {
                //countConsul = <?php //echo json_encode($_SESSION["countConsul"]); ?>;

                //for (let i = 0; i < countConsul; i++) {
                //    let ficha = document.createElement('div');
                //}
            //}
            
        }

    </script>
    <script src="JS/switch.js"></script>

</body>
</html>
