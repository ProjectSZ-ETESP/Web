<?php

session_start();

$idLog = $_SESSION["idLog"];

try {
    require_once "conn.php";

    $cLoadQuery = "CALL proc_consultaLoad(:id, @data, @hora, @clinica, @doutor, @tipoConsulta);";
    $cLoadStatement = $pdo->prepare($cLoadQuery);

    $cLoadStatement->bindParam(':id', $idLog);
    $cLoadStatement->execute();

    $cLoadReturn = "SELECT @data as data, @hora as hora, @clinica as clinica, @doutor as doutor, @tipoConsulta as tipoConsulta";
    $cLoadStatement = $pdo->query($cLoadReturn);
    
    while ($cLoadResult = $cLoadStatement->fetch(PDO::FETCH_ASSOC)) {
        $dataConsul = explode(',', $cLoadResult['data']);
        $horaConsul = explode(',', $cLoadResult['hora']);
        $clinicaConsul = explode(',', $cLoadResult['clinica']);
        $doutorConsul = explode(',', $cLoadResult['doutor']);
        $tipoConsultaConsul = explode(',', $cLoadResult['tipoConsulta']);
    }

    $_SESSION["countConsul"] = count($clinicaConsul);
    $_SESSION["dataConsul"] = $dataConsul;
    $_SESSION["horaConsul"] = $horaConsul;
    $_SESSION["clinicaConsul"] = $clinicaConsul;
    $_SESSION["doutorConsul"] = $doutorConsul;
    $_SESSION["tipoConsultaConsul"] = $tipoConsultaConsul;

    header("location: ../Consultas.php");

    $cLoadQuery = null;
    $cLoadStatement = null;
    $cLoadReturnNome = null;
    $cLoadStatementNome = null;
    $cLoadResultNome = null;

    die();

} catch (PDOException $e) {
    die("Erro na query: " . $e->getMessage());
}