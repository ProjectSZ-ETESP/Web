<?php
        session_start();
    
        if ($_SESSION["colorMode"] == "light") {
                $_SESSION["colorMode"] = "dark";
        }
        else if ($_SESSION["colormode"] == "dark") {
                $_SESSION["colorMode"] = "light";
        }

        header('Location: ../' . $_SERVER['HTTP_REFERER']);
