<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/conta.css">
    <link rel="shortcut icon" href="Imagens/cachorra.webp" type="image/x-icon">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conta</title>

</head>
<body onload="loadData()">
    <div class="principal">
        <header>
            <div class="divlogo">
                <a href="Index.php">  
                    <img src="Imagens/logoLight.webp" alt="logo" class="logo" id="logotipo">
                </a>
            </div>

            <div class="menu">
                <a href="Clinicas.html" class="fonte">Clínicas</a> <br>
                <a href="Consultas.html" class="fonte">Consultas</a> <br>
                <a href="Index.php" class="fonte">Início</a> <br>
                <a href="Perguntas.html" class="fonte">FAQ</a> <br>
            </div>

            <div class="switch">
                <div id="btnSwitch">
                        <div class="eclipse"> 
                        </div>
                        <img src="Imagens/light.webp" alt="sol" id="imgLight">
                        <img src="Imagens/dark.webp" alt="lua" id="imgDark">
                </div>
            </div>

        </header>
        <div class="containPerfil">
            <div class="fotopfp">
                <img src="Imagens/cachorra.webp" alt="">

            </div>

            <div class="info">
                <h1 class="tlt" id="nomeTitle">
                    <?php echo $_SESSION["nomeLog"]?>
                </h1>
                <p class="perfil" id="nome">
                <?php echo "Nome: " . $_SESSION["nomeLog"]?>
                </p>
                <p class="perfil" id="email">
                <?php echo "E-mail: " . $_SESSION["emailLog"]?>
                </p>
                <a href="DadosCompletos.php" class="size">Ver Dados Completos</a>
            </div>
            <div class="editar">
                <button id="btnEditar" class="botao"> <a href="EditarDados.html">Editar</a> </button>
            </div>
        </div>
    </div>
    <script>

    </script>
    <script src="JS/switch.js"></script>
    <script src="JS/login.js"></script>
</body>
</html>
