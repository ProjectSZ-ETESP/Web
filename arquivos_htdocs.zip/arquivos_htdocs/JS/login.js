function logCheck() {
    if (sessionStorage.getItem("idLog") != 0 && sessionStorage.getItem("idLog") != null) {
        document.getElementById('btnComece').innerHTML = "Ver Perfil";
        document.getElementById('linkComece').href = "Conta.php";
    }
}