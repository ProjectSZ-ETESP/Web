<?php
    session_start();

    if (!(isset($_SESSION["idConsul"]))) {
        $_SESSION["idConsul"] = "";
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagens/perfil7.webp" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Empresa</title>
</head>
<body>

    <div class="principal">
        
        <header>
            <div class="divlogo">
                <a href="Index.php">  
                    <img src="Imagens/logoLight.webp" alt="logo" class="logo" id="logotipo">
                </a>
            </div>
            
            <div class="menu">
                <a href="Clinicas.php" class="fonte">Clínicas</a> <br>
                <a href="Consultas.php" class="fonte">Consultas</a> <br>
                <a href="Conta.php" class="fonte">Conta</a> <br>
                <a href="Perguntas.php" class="fonte">FAQ</a> <br>
            </div>

            <div class="switch">
                <div id="btnSwitch">
                        <div class="eclipse"> 
                        </div>
                        <img src="Imagens/light.webp" alt="sol" id="imgLight">
                        <img src="Imagens/dark.webp" alt="lua" id="imgDark">
                </div>
            </div>

        </header>

        <div class="subprincipal">

            <div class="imagem">
                <img src="Imagens/criacionistas.webp" alt="templo" id="mainImage">
            </div>

            <div class="boas-vindas">
                <h1 class="fonte">Sobre os <br><span>Criacionistas</span></h1>
                <p class="fonte">
                    Os Criacionistas é um empresa com foco em Lorem ipsum dolor sit amet, 
                    consectetur adipiscing elit. Phasellus aliquet, nibh nec molestie tempus, 
                    justo ex ultricies sapien, sed finibus nulla justo ut tellus. Nam at enim 
                    nulla. Etiam purus sapien, hendrerit non massa et, sodales imperdiet mi. 
                    Pellentesque porttitor quis lorem nec suscipit. Vivamus sed est felis. 
                    Cras rutrum vitae purus a pulvinar. 
                </p>
            </div>

        </div>

        <footer class="botao">
                <div class="sobre">
                    <h3>Sobre nós</h3>
                    <a href="Criacionistas.php">Criacionistas</a> <br>
                    <a href="Perguntas.php">FAQ</a> <br>
                </div>

                <div class="siga">
                    <h3>Siga-nos</h3>
                    <a href="https://www.instagram.com" class="linkImg" target="_blank">
                        <img src="Imagens/instagram.webp" class="redes" alt="Logo do Instagram">
                    </a>
                    <a href="https://github.com/ProjectSZ-ETESP" class="linkImg" target="_blank">
                        <img src="Imagens/github.webp" class="redes" alt="Logo do Github">
                    </a>
                </div>
        </footer>
        
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            colorMode();
        });
    </script>
    <script src="JS/switch.js"></script>
</body>
</html>