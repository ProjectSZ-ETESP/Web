const logotipo = document.getElementById("logotipo");
const lua = document.getElementById("btnSwitch");
const questions = document.querySelectorAll(".ask");
const font = document.querySelectorById("nomeTitle")
const backgroundArray = [
    document.querySelector(".containPerfil"),
];


let light = false;

lua.addEventListener("click", () => {
    light = !light;
    if (light) {

        // Modo escuro  ffffff
        logotipo.src = "Imagens/logoDark.webp";
        nomeTitle.

        document.body.style.backgroundColor = "#111D13";
        document.querySelectorAll(".fonte").forEach((e) => {
            e.style.color = "#ffffff";
        });

        document.querySelectorAll(".fontes").forEach((e) => {
            e.style.color = "#ffffff";
        });

        document.querySelectorAll(".botao").forEach((e) => {
            e.style.backgroundColor = "#8FB996";
        });

        document.querySelectorAll(".pesquisa").forEach(e=>{
            e.classList.add("input-place-light");
            e.style.color="#00866c";
            
        });


        lua.style.backgroundColor = "#ffffff";
        document.querySelector(".eclipse").style.left =
        document.querySelector(".eclipse").parentElement.clientWidth*0.10 +"px";
        document.querySelector(".eclipse").style.backgroundColor = "#111D13";
        document.querySelectorAll(".botao").forEach(e=>{
            e.style.color = "#FFFFFF";
        });

        document.querySelectorAll(".btnEditar").forEach(e=>{
            e.style.backgroundColor= "#8FB996";
        });

        document.querySelectorAll(".perfil").forEach(e=>{
            e.style.color = "#FFFFFF"
        });

        backgroundArray.forEach(e=>{
            if(e)e.style.backgroundColor = "#6A876E";
        });


        if(document.querySelector(".ask")){
            questions.forEach(e=>{ 
                e.src = "Imagens/perguntasDark.webp";
            });
        }
   
        
    } else {
        // Modo claro
        logotipo.src = "Imagens/logoLight.webp";

        document.body.style.backgroundColor = "#EFF1ED";
        document.querySelectorAll(".fonte").forEach((e) => {
            e.style.color = "#000000";
        });

        document.querySelectorAll(".fontes").forEach((e) => {
            e.style.color = "#000000";
        });

        document.querySelectorAll(".botao").forEach((e) => {
            e.style.backgroundColor = "#3E8469";
        });

        document.querySelectorAll(".pesquisa").forEach(e=>{
            e.classList.remove("input-place-light");
            e.style.color="#585858";
            
        });
            
        lua.style.backgroundColor = "#3E8469";
        document.querySelector(".eclipse").style.left =
        document.querySelector(".eclipse").parentElement.clientWidth*0.63+"px";
        document.querySelector(".eclipse").style.backgroundColor = "#ffffff";


        document.querySelectorAll(".botao").forEach(e=>{
            e.style.backgroundColor = "#3E8469";
            e.style.color = "#ffffff";

        });

        document.querySelectorAll(".perfil").forEach(e=>{
            e.style.color = "#000000"
        });
      
        backgroundArray.forEach(e=>{
            if(e)e.style.backgroundColor = "#ffffff";
        });


        if(document.querySelector(".ask")){
            questions.forEach(e=>{
                e.src = "Imagens/perguntasLight.webp";
            });
        }
       
       /*/ const InitialColors = {
            bg: getStyle(html, "--bg"),
            bgPanel: getStyle(html, "--bg-panel"),
            colorHeadings: getStyle(html, "--color-Headings"),
            colorText:getStyle(html, "--color-text")
        }*/

    }
});
